# Referencias seguras para análisis en GitHub

Este repositorio contiene inventarios y referencias visuales no funcionales extraídas del ZIP original.

## Carpetas
- `01_Vistas_de_plantillas/`: hojas de contacto con marcas repetidas de `SIMULACIÓN / NO VÁLIDO COMO COMPROBANTE`.
- `02_Recursos_graficos/`: hojas de contacto de imágenes del APK Android.
- `03_Inventarios/`: rutas, tamaños, hashes SHA-256 y texto visible de HTML; no contiene el código fuente.

## Límites
No incluye APK, código de generación de comprobantes, fuentes originales, HTML/JS/CSS funcionales ni imágenes limpias de comprobantes. No se ejecutó ningún APK o script. Las vistas son únicamente para revisión y no acreditan pagos.

## Uso
Sube estos archivos al repositorio por carpetas. Cada imagen JPG se ha optimizado y cada archivo individual debe quedar por debajo de 25 MB.
